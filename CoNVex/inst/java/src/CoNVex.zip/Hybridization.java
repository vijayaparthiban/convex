
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.Option;


import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.kohsuke.args4j.Option;

/*
 * This script reads the output from UNAfold and extracts dG and Tm values Then,
 * it appends them to sequences to Sanger/Agilent exon catalog fasta file
 */
/**
 * @author Parthiban Vijayarangakannan - pv1@sanger.ac.uk Genome Mutation and
 * Genetic Disease (Team 29) The Sanger Institute
 */
public class Hybridization {

    @Option(name = "-unafold_file_prefix", usage = "Prefix (starting file name) of a UNAfold file")
    private String unafold_output_prefix = "";
    @Option(name = "-regions_file", usage = "Input regions file")
    private String regions_file = "";
    @Option(name = "-input_fasta_file", usage = "Original input fasta file (generated from the regions file)")
    private String input_fasta = "";
    @Option(name = "-file_count", usage = "Number of UNAfold output files - also used for generating file name (integer N>=1)")
    private String file_count = "";
    @Option(name = "-probe_length", usage = "Length of the probe in bp (e.g., Agilent's typical probe length 120 bp)")
    private String pl = "";

    public void getdGTm(String[] args) throws Exception {

        CmdLineParser parser = new CmdLineParser(this);
        try {
            parser.parseArgument(args);
        } catch (CmdLineException cle) {
            System.err.println(cle.getMessage());
            parser.printUsage(System.err);
        }

        if (unafold_output_prefix.equals("") || input_fasta.equals("") || file_count.equals("") || regions_file.equals("")) {
            System.err.println("Required options are missing!");
            System.err.println("Usage: java Hybridization -unafold_file_prefix <file_prefix> -regions_file <regions_file> -input_fasta_file /path/to/file.fa -file_count <N>");
            System.err.println("Type -help or -<anyjunk> to display the options :)");
            System.exit(-1);
        }

        String output_fasta = input_fasta.substring(0, input_fasta.lastIndexOf(".")) + "_dGTm.fa";
        String output_regions = regions_file.substring(0, regions_file.lastIndexOf(".")) + "_dGTm.txt";

        BufferedReader br = null;
        Pattern p = Pattern.compile("^([\\dXYMT]+)\\t(\\d+)\\t(\\d+).*"); // chr, start, end
        Matcher m = null;

        int count = 0, count1 = 0;
        String s = "";
        String s1 = "";
        boolean closegate = false;
        int fc = Integer.parseInt(file_count);
        HashMap<String, String> hm = new HashMap<String, String>();

        for (int i = 1; i <= fc; i++) { // 10 times for 10 files for example - file_count times the number of files

            //String unafold_output_file = "/nfs/analysis_bakeoff/EXOME/DDD/DDDexome_baits/rnae_unafold_output_DDD_" + i + ".out";
            //String unafold_output_file = "/nfs/analysis_bakeoff/EXOME/UK10K/UNAfold/rnae_unafold_output_SS50_extra187" + ".out";
            String unafold_output_file = unafold_output_prefix + i + ".txt";

            br = new BufferedReader(new FileReader(unafold_output_file));

            HashMap<String, String> hm1 = new HashMap<String, String>();

            while ((s = br.readLine()) != null) {

                if (s.contains("Calculating")) {

                    hm1.put("" + count, s.substring(s.indexOf("for") + 4, s.lastIndexOf("-rna")));
                    ++count;

                } else {
                    if (s.contains("----------------") || s.trim().equals("")) {
                        closegate = true;
                    }
                    if (!closegate && !s.contains("dG\tdH")) {
                        hm.put(hm1.get("" + count1), s);
                        ++count1;
                    }
                }
            }
            closegate = false;
            br.close();
            System.out.println("Found " + count + " hybridization values including " + unafold_output_file);
        }

        //String output_fasta = "/nfs/analysis_bakeoff/EXOME/UK10K/UNAfold/SureSelect_All_Exon_50mb_with_annotation.hg19.UCSC.RANDOM_dGTm.fa";
        //String input_fasta = "/nfs/analysis_bakeoff/EXOME/UK10K/UNAfold/SureSelect_All_Exon_50mb_with_annotation.hg19.UCSC.RANDOM.fa";
        BufferedReader br1 = new BufferedReader(new FileReader(input_fasta));
        BufferedWriter bw1 = new BufferedWriter(new FileWriter(output_fasta));
        String dGTm = "";
        String tab = "\t";
        s1 = "";
        String chr = "";
        int start = 0, end = 0;

        while ((s = br1.readLine()) != null) {

            if (s.contains(">")) {
                String[] fastatitle = s.split("\\s+");
                s1 = hm.get(fastatitle[0].substring(1).trim());
                String[] unafold_output = s1.split("\t");
                dGTm = tab + "dG=" + unafold_output[0] + tab + "Tm=" + unafold_output[3];
                s += dGTm;
            }
            bw1.write(s + "\n");
        }

        bw1.close();
        br1.close();

        br1 = new BufferedReader(new FileReader(regions_file));
        bw1 = new BufferedWriter(new FileWriter(output_regions));

        int len = 0, probe_length = Integer.parseInt(pl);
        double dGnorm = 0;
        
        while ((s = br1.readLine()) != null) {

            m = p.matcher(s);

            if (m.find()) {

                chr = m.group(1);
                start = Integer.parseInt(m.group(2));
                end = Integer.parseInt(m.group(3));
                s1 = hm.get(chr + ":" + start + ":" + end);
                len = end-start;
                
                String[] unafold_output = s1.split("\t");
                dGnorm = Double.parseDouble(unafold_output[0])/(double)Math.floor(len/probe_length); // norm-dG = rawdG/#probes (approx)
                dGnorm = Math.round(dGnorm*10.0)/10.0;

                dGTm = s + tab + dGnorm + tab + unafold_output[3] + "\n";
                bw1.write(dGTm);
            }
        }

        bw1.close();
        br1.close();

        System.out.println("Written fasta file with raw dG/Tm: " + output_fasta);
        System.out.println("Written regions file with normalised dG/Tm: " + output_regions);
    }

    public static void main(String[] args) throws Exception {
        new Hybridization().getdGTm(args);
    }
}
