
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.Option;

import java.io.*;
import org.biojava.bio.*;
import org.biojava.bio.seq.*;
import org.biojava.bio.seq.db.*;
import org.biojava.bio.seq.io.*;
import org.biojava.bio.symbol.SymbolList;

/**
 * @author Parthiban Vijayarangakannan - pv1@sanger.ac.uk 
 * Genome Mutation and Genetic Disease Group (Team 29) The Sanger Institute
 */
public class FastaRevComp {

    @Option(name = "-fasta_file", usage = "Fasta file name with full location")
    private String fasta_file = "";
    @Option(name = "-max_seq", usage = "Number of sequences in fasta file (for fast memory efficient processing)")
    private String max_seq = "";
    @Option(name = "-split_into", usage = "Split the original fasta file into N number of files (integer N>=1)")
    private String split_into = "";

    public void splitRevComp(String[] args) throws Exception {

        CmdLineParser parser = new CmdLineParser(this);
        try {
            parser.parseArgument(args);
        } catch (CmdLineException cle) {
            System.err.println(cle.getMessage());
            parser.printUsage(System.err);
        }

        if (fasta_file.equals("") || max_seq.equals("") || split_into.equals("")) {
            System.err.println("Required options are missing!");
            System.err.println("Usage: java FastaRevComp -fasta_file /path/to/file.fa -max_seq <N> -split_into <N>");
            System.err.println("Type -help or -<anyjunk> to display the options :)");
            System.exit(-1);
        }

        try {
            //prepare a BufferedReader for file io
            //BufferedReader br = new BufferedReader(new FileReader("/nfs/analysis_bakeoff/EXOME/UK10K/UNAfold/SureSelect_All_Exon_50mb_with_annotation.hg19.fa")); // UK10K file
            //BufferedReader br = new BufferedReader(new FileReader("/nfs/analysis_bakeoff/EXOME/DDD/DDDexome_baits/033743_D_DNAFront_BCBottom_20110419.fa"));
            //BufferedReader br = new BufferedReader(new FileReader("/nfs/analysis_bakeoff/EXOME/DDD/DDDexome_baits/NEW2/SureSelect_All_Exon_50mb_with_annotation.hg19.UCSC.RANDOM.fa"));

            //String revcompfile = "/nfs/analysis_bakeoff/EXOME/DDD/DDDexome_baits/NEW2/SureSelect_All_Exon_50mb_with_annotation.hg19.UCSC.RANDOM_revcomp";
            //String rnafile = "/nfs/analysis_bakeoff/EXOME/DDD/DDDexome_baits/NEW2/SureSelect_All_Exon_50mb_with_annotation.hg19.UCSC.RANDOM.fa_rna";

            BufferedReader br = new BufferedReader(new FileReader(fasta_file));

            //Output files
            String revcompfile = fasta_file.substring(0, fasta_file.lastIndexOf(".")) + "_revcomp";
            String rnafile = fasta_file.substring(0, fasta_file.lastIndexOf(".")) + "_rna";

            SequenceDB db = new HashSequenceDB();
            int nf = Integer.parseInt(split_into);
            if (nf == 0) {
                nf = 1;
            }
            int no_of_input_seqs = (Math.round(Integer.parseInt(max_seq) / nf) * nf) + nf; //  Calculates Max number of sequences + additional value that makes it divisible by number of files to be split
            int splitpoint = no_of_input_seqs / nf; //  splitpoints based on no_of_input_seqs

            SequenceIterator iter = SeqIOTools.readFastaDNA(br);
            Sequence seq;
            String rnaseq;
            SymbolList revcomp;
            String greater = ">";
            String rna = "-rna";
            String newline = "\n";
            int splitcounter = 0;
            int i = 1;

            BufferedWriter bw = new BufferedWriter(new FileWriter(revcompfile + i + ".fa"));
            BufferedWriter bw1 = bw1 = new BufferedWriter(new FileWriter(rnafile + i + ".fa"));

            while (iter.hasNext()) {


                seq = (Sequence) iter.nextSequence();
                revcomp = DNATools.reverseComplement(seq);
                rnaseq = DNATools.toRNA(seq).seqString().toUpperCase();

                // Reverse complementary DNA
                bw.write(greater + seq.getName() + newline);
                bw.write(revcomp.seqString().toUpperCase() + newline);
                //  Transcribed original DNA to RNA
                bw1.write(greater + seq.getName() + rna + newline);
                bw1.write(rnaseq + newline);
                ++splitcounter;

                if (splitcounter % splitpoint == 0) {

                    bw.close();
                    bw1.close();
                    System.out.println("Written file: " + revcompfile + i + ".fa");
                    System.out.println("Written file: " + rnafile + i + ".fa");

                    if (iter.hasNext()) {
                        ++i;
                        bw = new BufferedWriter(new FileWriter(revcompfile + i + ".fa"));
                        bw1 = new BufferedWriter(new FileWriter(rnafile + i + ".fa"));
                    }
                }
            }

            //SeqIOTools.writeFasta(ous, db);
            bw.close();
            bw1.close();
            br.close();
            System.out.println("Last written file was: " + revcompfile + i + ".fa");
            System.out.println("Last written file was: " + rnafile + i + ".fa");


        } catch (FileNotFoundException ex) {
            //can't find file specified by args[0]
            ex.printStackTrace();
        } catch (BioException ex) {
            //error parsing requested format
            ex.printStackTrace();
        }

    }

    public static void main(String[] args) throws Exception {
        new FastaRevComp().splitRevComp(args);
    }
}