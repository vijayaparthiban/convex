/*
 * Calculates SampleMedians (Autosomes and X) and SampleMads
 */

/**
 * @author Parthiban Vijayarangakannan - pv1@sanger.ac.uk Genome Mutation and
 * Genetic Disease (Team 29) The Sanger Institute
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class SampleMediansMads {

    @Option(name = "-sample_info_file", usage = "Sample info file from Step 1")
    private String si_file = "";
    @Option(name = "-num_probes_auto", usage = "No. of autosomal probe regions")
    private String num_probes_auto = "";
    @Option(name = "-num_probes_X", usage = "No. of Chr X probe regions")
    private String num_probes_X = "";
    @Option(name = "-output_file", usage = "Output file to save medians and MADs")
    private String output_file = "";
    static final String dash = "-", colon = ":", newline = "\n", tab = "\t", nstr = "";

    public void getMediansMads(String[] args) throws Exception {
        CmdLineParser parser = new CmdLineParser(this);
        try {
            parser.parseArgument(args);
        } catch (CmdLineException cle) {
            System.err.println(cle.getMessage());
            parser.printUsage(System.err);
        }

        if (si_file.equals("") || num_probes_auto.equals("") || num_probes_X.equals("")) {
            System.err.println("Required options are missing!");
            System.err.println("Usage: java SampleMediansMads -sample_info_file /path/to/file.txt -num_probes_auto <num_probes_auto> -num_probes_X <num_probes_X> -output_file /path/to/SampleMedians_Mads_output_file.txt");
            System.err.println("Type -help or -<anyjunk> to display the options :)");
            System.exit(-1);
        }
        Pattern p = Pattern.compile("^([\\dXYMT]+)\\t\\d+\\t\\d+\\t(.+?)\\t.*"); // chr, start, end
        Matcher m;

        BufferedReader br = new BufferedReader(new FileReader(si_file));
        BufferedReader br1 = null;
        List<String> sample_ids = new ArrayList<String>();
        List<String> gam_files = new ArrayList<String>();
        List<String> gender = new ArrayList<String>();

        String s = "", chr = "";
        int Apr_count = Integer.parseInt(num_probes_auto);
        int Xpr_count = Integer.parseInt(num_probes_X);
        double[] l2r_auto = new double[Apr_count];
        double[] l2r_X = new double[Xpr_count];
        // Read the Sample info file
        while ((s = br.readLine()) != null) { // Read-in the sample info file
            String[] line = s.split("\t");
            sample_ids.add(line[0]);
            gender.add(line[1]);
            gam_files.add(line[5]);
        }
        s = "";
        int i = 0, j = 0;
        double medianX = 0;
        double[] median_mad_values = new double[2];
        BufferedWriter bw = new BufferedWriter(new FileWriter(output_file));
        bw.write("sample_id" + tab + "Gender" +  tab + "SampleMads" + tab + "SampleMediansAuto" + tab + "SampleMediansX" + newline);

        for (int f = 0; f < gam_files.size(); f++) {
            medianX = 0; median_mad_values[0] = 0.0; median_mad_values[1] = 0.0;
            br1 = new BufferedReader(new FileReader(gam_files.get(f)));
            i = 0; j = 0;
            while ((s = br1.readLine()) != null) { // Read-in the gam file

                m = p.matcher(s);
                if (m.find()) {
                    chr = m.group(1);
                    if (chr.equals("X")) {
                        l2r_X[i] = Double.parseDouble(m.group(2));
                        ++i;
                    } else {
                        l2r_auto[j] = Double.parseDouble(m.group(2));
                        ++j;
                    }
                }
            }
            medianX = median(l2r_X);
            medianX = Math.round(medianX * 1000.0) / 1000.0;
            median_mad_values = median_mad(l2r_auto); //[0] = median; [1] = MAD
            bw.write(sample_ids.get(f) + tab + gender.get(f) + tab + median_mad_values[1] + tab + median_mad_values[0] + tab + medianX + newline);
        }
        bw.close();
    }

    private double median(double[] l) {
        Arrays.sort(l);
        int middle = l.length / 2;
        if (l.length % 2 == 0) {
            double left = l[middle - 1];
            double right = l[middle];
            return (left + right) / 2;
        } else {
            return l[middle];
        }
    }

    private double[] median_mad(double[] logratios) {

        double[] median_mad = new double[2];
        int data_length = logratios.length;
        double[] deviations = new double[data_length];
        median_mad[0] = median(logratios);
        for (int i = 0; i < data_length; i++) {
            deviations[i] = Math.abs(logratios[i] - median_mad[0]);
        }
        median_mad[1] = median(deviations);
        median_mad[0] = Math.round(median_mad[0] * 1000.0) / 1000.0;
        median_mad[1] = Math.round(median_mad[1] * 1000.0) / 1000.0;

        //Arrays.sort(deviations);
        return median_mad;
    }

    public static void main(String[] args) throws Exception {
        new SampleMediansMads().getMediansMads(args);
    }
}
