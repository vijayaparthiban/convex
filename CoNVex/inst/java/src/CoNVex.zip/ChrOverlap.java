
/**
 * @author Parthiban Vijayarangakannan - pv1@sanger.ac.uk Genome Mutation and
 * Genetic Disease (Team 29) The Sanger Institute
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class ChrOverlap {

    @Option(name = "-chr_list1", usage = "List 1 with Chr regions (Chr, Start and End) in the first 3 columns ")
    private String chr_list1 = "";
    @Option(name = "-chr_list2", usage = "List 2 with Chr regions - % overlap of this list is returned as output")
    private String chr_list2 = "";
    public static final String dash = "-", colon = ":", newline = "\n", tab = "\t", nstr = "";

    public void filterLists(String[] args) throws Exception {

        CmdLineParser parser = new CmdLineParser(this);
        try {
            parser.parseArgument(args);
        } catch (CmdLineException cle) {
            System.err.println(cle.getMessage());
            parser.printUsage(System.err);
        }

        if (chr_list1.equals("") || chr_list2.equals("")) {

            System.err.println("Two lists of Chr regions are required!");
            System.err.println("Usage: java ChrOverlap -chr_list1 /path/to/chr_file1.txt -chr_list2 /path/to/chr_file2.txt");
            System.err.println("Type -help or -<anyjunk> to display the options :)");
            System.exit(-1);
        }
        //System.err.println("Comparing Chr lists:");
        //System.err.println(chr_list1);
        //System.err.println(chr_list2);

        Pattern p = Pattern.compile("^([\\dXYMT]+)\\t(\\d+)\\t(\\d+).*"); // For consensus report
        Pattern p1 = Pattern.compile("^\\d+\\t([\\dXYMT]+)\\t(\\d+)\\t(\\d+)\\t[\\d\\t]+{14}"); // Pileup summary list
        //Pattern p2 = Pattern.compile("^.+\\t(\\d+\\t\\d+\\t\\d+\\t\\d+\\t\\d+\\t\\d+\\t[\\d\\.]+\\t[\\d\\.]+\\t[\\d\\.]+)");
        Matcher m = null, m1 = null, m2 = null;

        BufferedReader br = new BufferedReader(new FileReader(chr_list1));
        String s = "", s1 = "", s2 = "", s3 = "";
        String chr = "", start = "", end = "";
        int ch = 0, st = 0, en = 0, i = 0;

        HashMap<String, String> chr_start = new HashMap<String, String>();

        while ((s = br.readLine()) != null) {
            m = p.matcher(s);
            if (m.find()) {
                chr = m.group(1);
                start = m.group(2);
                end = m.group(3);
                chr_start.put(chr + colon + start + dash + end, nstr);
            }
        }
        br.close();
        
        int[][] chrloc = new int[3][chr_start.size()];

        for (String loc : chr_start.keySet()) {

            chr = loc.substring(0, loc.indexOf(colon)).trim();

            if (chr.equalsIgnoreCase("X")) {
                ch = 23;
            } else if (chr.equalsIgnoreCase("Y")) {
                ch = 24;
            } else if (chr.equalsIgnoreCase("MT")) {
                ch = 25;
            } else {
                ch = Integer.parseInt(chr);
            }
            chrloc[0][i] = ch;
            chrloc[1][i] = Integer.parseInt(loc.substring(loc.indexOf(colon) + 1, loc.lastIndexOf(dash)).trim());
            chrloc[2][i] = Integer.parseInt(loc.substring(loc.indexOf(dash) + 1).trim());
            ++i;
        }

        BufferedReader br1 = new BufferedReader(new FileReader(chr_list2));
        ch = 0;
        double pcoverlap;

        while ((s = br1.readLine()) != null) {

            pcoverlap = 0;
            m1 = p.matcher(s);

            if (m1.find()) {
                chr = m1.group(1);

                if (chr.equalsIgnoreCase("X")) {
                    ch = 23;
                } else if (chr.equalsIgnoreCase("Y")) {
                    ch = 24;
                } else if (chr.equalsIgnoreCase("MT")) {
                    ch = 25;
                } else {
                    ch = Integer.parseInt(chr);
                }
                st = Integer.parseInt(m1.group(2));
                en = Integer.parseInt(m1.group(3));

                pcoverlap = getFrequency(chrloc, ch, st, en);
                System.out.println(pcoverlap);
            }
        }
    }

    public static double getFrequency(int[][] chrloc, int ch, int start, int end) {

        int ocase = 0;
        double[] opp = {0, 0};
        double maxpcoverlap = 0;

        for (int i = 0; i < chrloc[0].length; i++) {

            if (chrloc[0][i] == ch) {
                ocase = 0;
                if (start >= chrloc[1][i] && start <= chrloc[2][i]) {
                    if (chrloc[2][i] >= start && chrloc[2][i] <= end) {
                        ocase = 1;
                    } else {
                        ocase = 2;
                    }
                    opp = getOverlapLength(start, end, chrloc[1][i], chrloc[2][i], ocase);
                    if (opp[1] >= maxpcoverlap) {
                        maxpcoverlap = opp[1];
                    }

                } else if (chrloc[1][i] >= start && chrloc[1][i] <= end) {
                    if (chrloc[2][i] >= start && chrloc[2][i] <= end) {
                        ocase = 3;
                    } else {
                        ocase = 4;
                    }
                    opp = getOverlapLength(start, end, chrloc[1][i], chrloc[2][i], ocase);
                    if (opp[1] >= maxpcoverlap) {
                        maxpcoverlap = opp[1];
                    }
                }

            }
        }
        return maxpcoverlap;
    }

    public static double[] getOverlapLength(int start, int end, int chrloc_start, int chrloc_end, int ocase) {

        double[] opp = {0, 0};
        int exl = end - start + 1;

        switch (ocase) {
            case 1:
                opp[0] = chrloc_end - start + 1;
                opp[1] = opp[0] * 100 / exl;
                break;
            case 2:
                opp[0] = exl;
                opp[1] = 100;
                break;
            case 3:
                opp[0] = chrloc_end - chrloc_start + 1;
                opp[1] = opp[0] * 100 / exl;
                break;
            case 4:
                opp[0] = end - chrloc_start + 1;
                opp[1] = opp[0] * 100 / exl;
                break;
        }
        return opp;
    }

    public static void main(String[] args) throws Exception {
        new ChrOverlap().filterLists(args);
    }
}
