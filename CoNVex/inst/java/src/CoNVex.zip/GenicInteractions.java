
import java.io.*;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;
import org.hupo.psi.mi.psicquic.wsclient.*;

/*
 * Protein-Protein interaction extractor
 */
/**
 * @author Parthiban Vijayarangakannan - pv1@sanger.ac.uk Genome Mutation and
 * Genetic Disease Group (Team 29) - The Sanger Institute Date: 22.01.2012
 */
public class GenicInteractions {

    @Option(name = "-psicquic_clients", usage = "List of active PSICQUIC clients (optional)")
    private String psicquic_clients = "";
    @Option(name = "-cnv_gene_list", usage = "CNV list with gene names in COLUMN 8")
    private String cnv_gene_list = "";
    @Option(name = "-ddg2p", usage = "File containing the DDG2P gene list")
    private String ddg2p_file = "";
    @Option(name = "-organisms", usage = "Organisms 'human,mouse,worm,fruitfly,rat' (optional; default: human)") // default: human only
    private String organisms = "1";
    public static final String dash = "-", colon = ":", newline = "\n", tab = "\t", nstr = "";
    public static final Pattern p3m = Pattern.compile("^(?:.+\\t){4}(.+)\\t(.+)\\t(?:.+\\t){3}taxid:9606.+\\ttaxid:9606.+\\t(?:.+\\t){2}.+edgetype:X\\t.+");
    public static final Pattern p4m = Pattern.compile("^(?:.+\\t){4}(.+)\\t(.+)\\t(?:.+\\t){5}(?:.+\\t){2}.+edgetype:X\\t.+");

    public void extractPPIs(String[] args) throws Exception {

        // Get the interaction lists
        CmdLineParser parser = new CmdLineParser(this);
        try {
            parser.parseArgument(args);
        } catch (CmdLineException cle) {
            System.err.println(cle.getMessage());
            parser.printUsage(System.err);
        }

        if (cnv_gene_list.equals("")) {

            System.err.println("CNV list is mandatory!");
            System.err.println("Usage: java GenicInteractions -ppi_dbs_file /path/to/chr_file1.txt -ddg2p /path/to/chr_file2.txt");
            System.err.println("Type -help or -<anyjunk> to display the options :)");
            System.exit(-1);
        }
        String output_file = cnv_gene_list.substring(0, cnv_gene_list.lastIndexOf(".")) + ".INTERACTIONS.txt";
        //String output_file_cs = cnv_gene_list.substring(0, cnv_gene_list.lastIndexOf(".")) + "_ppi_cs.txt";
        //String output_file_within = cnv_gene_list.substring(0, cnv_gene_list.lastIndexOf(".")) + "_ppi_within.txt";

        String s = "";
        int num_genes = 0, count1 = 0, count2 = 0;
        //String chr = "", start = "", end = "";
        String gene_names = "", igstr = "";
        String[] interactors = new String[2];

        //Pattern p = Pattern.compile("^([\\dXYMT]+)\\t(\\d+)\\t(\\d+).*"); // chr, start, end
        //Pattern p1 = Pattern.compile("^[\\dXYMT]+\\t\\d+\\t\\d+\\t.+\\t.+\\t(.+)\\t.*"); // chr, start, end
        Pattern p2 = Pattern.compile("^([\\dXYMT]+)\\t(\\d+)\\t(\\d+)\\t.+\\t(.+)\\t.+\\t.+\\t.*"); // chr, start, end

        Matcher m = null, m1 = null;

        HashMap<String, String> cnv_regions = new HashMap<String, String>();
        HashMap<String, String> ddg2p = new HashMap<String, String>();
        HashMap<String, String> ddg2p_genes = new HashMap<String, String>();

        HashMap<String, String> interacting_genes = new HashMap<String, String>();

        BufferedReader br = new BufferedReader(new FileReader(cnv_gene_list));
        while ((s = br.readLine()) != null) {
            String[] s1 = s.split("\t");
            //m = p.matcher(s);
            cnv_regions.put(s1[0].trim() + colon + s1[1].trim() + dash + s1[2].trim() + colon + s1[6].trim(), s);
            //System.out.println("CNV regions: " + s1[0].trim() + colon + s1[1].trim() + dash + s1[2].trim() + colon + s1[7].trim());
        }
        br.close();
        s = "";

        if (!ddg2p_file.equals("")) {
            br = new BufferedReader(new FileReader(ddg2p_file));
            while ((s = br.readLine()) != null) {
                //System.out.println("s: "+s);
                m = p2.matcher(s);
                if (m.find()) {
                    ddg2p.put(m.group(1) + colon + m.group(2) + dash + m.group(3), s);
                    ddg2p_genes.put(m.group(4).toLowerCase(), s);
                    //System.out.println(m.group(4));
                }
            }
            br.close();
        }


        //PsicquicSimpleClient client = new PsicquicSimpleClient("http://www.ebi.ac.uk/Tools/webservices/psicquic/intact/webservices/current/search/");

        PsicquicSimpleClient client = new PsicquicSimpleClient("http://irefindex.uio.no:8080/psicquic-ws/webservices/current/search/");

        for (String cnvr : cnv_regions.keySet()) {

            String[] s2 = cnv_regions.get(cnvr).split("\t");
            //m1 = p1.matcher(cnv_regions.get(cnvr));
            interacting_genes = new HashMap<String, String>();
            igstr = "";
            gene_names = s2[7].trim();
            count1 = gene_names.length();

            if (!gene_names.equals("NA")) {

                // gene names separated by 'or' - MIQL query
                gene_names = gene_names.substring(0, gene_names.length() - 1).replaceAll(";", " or ").toLowerCase();
                count2 = gene_names.length();
                num_genes = (count2 - count1) / 3;
                // System.out.println(gene_names);

                if (num_genes > 20) {
                    igstr = "LARGE-CNV";
                } else {
                    final long count = client.countByQuery(gene_names);
                    //System.out.println("Count: " + count);

                    if (count > 0) {
                        try {
                            final InputStream result = client.getByQuery(gene_names);
                            BufferedReader in = new BufferedReader(new InputStreamReader(result));

                            while ((s = in.readLine()) != null) {
                                //System.out.println(s);
                                interactors = getInteractors(s, Integer.parseInt(organisms));
                                //System.out.println("InteratorsFull: " + interactors[0] + " <--> " + interactors[1]);
                                String[] intr1 = interactors[0].toLowerCase().split("\\|");
                                String[] intr2 = interactors[1].toLowerCase().split("\\|");

                                for (String in1 : intr1) {
                                    // System.out.println("in1" + in1);
                                    if (in1.contains("locuslink:")) {
                                        interacting_genes.put(in1.substring(in1.indexOf("locuslink:") + 10), nstr);
                                        //System.out.println("IF-Split: " + in1.substring(in1.indexOf("locuslink:") + 10));
                                    }
                                }
                                for (String in2 : intr2) {
                                    //System.out.println("in2" + in2);

                                    if (in2.contains("locuslink:")) {
                                        interacting_genes.put(in2.substring(in2.indexOf("locuslink:") + 10), nstr);
                                        //System.out.println("IF-Split: " + in2.substring(in2.indexOf("locuslink:") + 10));
                                    }
                                }
                                String[] gnn = gene_names.split(";");
                                for (String is : gnn) {
                                    if (interacting_genes.containsKey(is)) {
                                        interacting_genes.remove(is);
                                    }
                                }

                            }

                            in.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    } else {
                        igstr = "NA";
                    }
                }
                if (!ddg2p_file.equals("")) {

                    for (String intr3 : interacting_genes.keySet()) {
                        if (ddg2p_genes.containsKey(intr3)) {
                            igstr = intr3 + "[*];" + igstr;
                        } else {
                            igstr += intr3 + ";";
                        }
                    }
                }
            } else {
                igstr = "NA";
            }
            cnv_regions.put(cnvr, cnv_regions.get(cnvr) + tab + igstr);

        }
        br = new BufferedReader(new FileReader(cnv_gene_list));
        BufferedWriter bw = new BufferedWriter(new FileWriter(output_file));
        while ((s = br.readLine()) != null) {
            String[] s1 = s.split("\t");
            //System.out.println(cnv_regions.get(s1[0].trim() + colon + s1[1].trim() + dash + s1[2].trim() + colon + s1[6].trim()));
            bw.write(cnv_regions.get(s1[0].trim() + colon + s1[1].trim() + dash + s1[2].trim() + colon + s1[6].trim()) + newline);
        }
        br.close();
        bw.close();
        System.out.println("Output interactions file:");
        System.out.println(output_file);
    }

    public String[] getInteractors(String mitab_line, int org_type) {

        String[] intp = new String[2];
        intp[0] = "";
        intp[1] = "";
        Matcher mat = null;

        switch (org_type) {
            case 1: // HUMAN only
                mat = p3m.matcher(mitab_line);
                if (mat.find()) {
                    intp[0] = mat.group(1);
                    intp[1] = mat.group(2);
                }
                break;
            case 2: // Vertebrates - Human, Mouse and Rat
                if (mitab_line.contains("taxid:9606") || mitab_line.contains("taxid:10090") || mitab_line.contains("taxid:10116")) {
                    mat = p4m.matcher(mitab_line);
                    if (mat.find()) {
                        intp[0] = mat.group(1);
                        intp[1] = mat.group(2);
                    }
                }
                break;
            case 3: // All 
                mat = p4m.matcher(mitab_line);
                if (mat.find()) {
                    intp[0] = mat.group(1);
                    intp[1] = mat.group(2);
                }
                break;
            default: // Human only
                mat = p3m.matcher(mitab_line);
                if (mat.find()) {
                    intp[0] = mat.group(1);
                    intp[1] = mat.group(2);
                }
                break;
        }
        return intp;
    }

    public static void main(String[] args) throws Exception {
        new GenicInteractions().extractPPIs(args);
    }
}
// java -cp $CLASSPATHPQ -Dhttp.proxyHost=wwwcache.sanger.ac.uk -Dhttp.proxyPort=3128 GenicInteractions -cnv_gene_list /nfs/ddd0/parthiban/CNVlists/09012013/Convex_09012013_v1_CV.GENES.txt -ddg2p /nfs/ddd0/parthiban/DDG2P_20121101_v1.2_with_positions.txt

/*
 * INFO:
 * # Interactors for each gene annotated separately to identify 'which' gene it is
 * # Evaluate iRefIndex once again - sources, their versions, etc.
 * # Include REACTOME data too!!
 * # Cytoscape visualisation file for each sample
 */