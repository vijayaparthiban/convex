
/**
 * @author Parthiban Vijayarangakannan - pv1@sanger.ac.uk Genome Mutation and
 * Genetic Disease (Team 29) The Sanger Institute
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class CompareLists {

    @Option(name = "-chr_list1", usage = "List 1 with Chr regions (Chr, Start and End) in the first 3 columns ")
    private String chr_list1 = "";
    @Option(name = "-chr_list2", usage = "List 2 with Chr regions - % overlap of this list is returned as output")
    private String chr_list2 = "";
    @Option(name = "-sampleID_col1", usage = "(optional) The column number (count starts from 1) of the Sample ID")
    private String sampleID_col1 = "";
    @Option(name = "-sampleID_col2", usage = "(optional) The column number (count starts from 1) of the Sample ID")
    private String sampleID_col2 = "";
    @Option(name = "-ro_threshold", usage = "(optional) Reciprocal overlap threshold in percentage")
    private String ro_threshold = "0";
    @Option(name = "-ddd_aliases", usage = "(optional) DDD aliases")
    private String ddd_aliases = "0";
    public static final String dash = "-", colon = ":", newline = "\n", tab = "\t", nstr = "", at = "@";

    public void estimateFreq(String[] args) throws Exception {

        CmdLineParser parser = new CmdLineParser(this);
        try {
            parser.parseArgument(args);
        } catch (CmdLineException cle) {
            System.err.println(cle.getMessage());
            parser.printUsage(System.err);
        }

        if (chr_list1.equals("")) {
            System.err.println("Two lists of Chr regions are required!");
            System.err.println("Usage: java CompareLists -chr_list1 /path/to/chr_file1.txt -chr_list2 /path/to/chr_file2.txt [options]");
            System.err.println("Type -help or -<anyjunk> to display the options :)");
            System.exit(-1);
        }
        int sidcol1 = 1; //
        if (!sampleID_col1.equals("")) {
            sidcol1 = Integer.parseInt(sampleID_col1) - 1; //
        }
        int sidcol2 = 6; //
        if (!sampleID_col2.equals("")) {
            sidcol2 = Integer.parseInt(sampleID_col2) - 1; //
        }
        int ro_thres = Integer.parseInt(ro_threshold);
        //System.err.println("Comparing Chr lists:");
        //System.err.println(chr_list1);
        //System.err.println(chr_list2);

        Pattern p = Pattern.compile("^([\\dXYMT]+)\\t(\\d+)\\t(\\d+).*"); // For consensus report
        Matcher m = null;

        BufferedReader br = new BufferedReader(new FileReader(chr_list1));
        String s = "";
        String chr = "", start = "", end = "";
        int ch = 0, st = 0, en = 0;
        int line = 0;

        List<String> chr_start = new ArrayList<String>();
        List<String> chr_start_extras = new ArrayList<String>();

        List<String> sample_ids = new ArrayList<String>();

        while ((s = br.readLine()) != null) { // aCGH list
            //m = p.matcher(s);
            if (line != 0) {

                String[] ss = s.split("\t");
                chr = ss[2];
                start = ss[3];
                end = ss[4];
                chr_start.add(chr + colon + start + dash + end + at + ss[34] + ";" + ss[35]);
                chr_start_extras.add(s);
                sample_ids.add(ss[sidcol1]);
                //System.out.println(ss[sidcol1]);
            }
            ++line;
        }
        br.close();

       // System.out.println("chr start " + chr_start.size());

        int[][] chrloc = new int[3][chr_start.size()];
        String sid = "";
        int sidcount = 0;

        for (int i = 0; i < chr_start.size(); i++) {

            String loc = chr_start.get(i);
            String stmp = sample_ids.get(i);

            if (!sid.equals(stmp)) {
                sid = stmp;
                ++sidcount;
            }
            //sidtrack[i] = sidcount;
            chr = loc.substring(0, loc.indexOf(colon)).trim();

            if (chr.equalsIgnoreCase("X")) {
                ch = 23;
            } else if (chr.equalsIgnoreCase("Y")) {
                ch = 24;
            } else if (chr.equalsIgnoreCase("MT")) {
                ch = 25;
            } else {
                ch = Integer.parseInt(chr);
            }
            chrloc[0][i] = ch;
            chrloc[1][i] = Integer.parseInt(loc.substring(loc.indexOf(colon) + 1, loc.lastIndexOf(dash)).trim());
            chrloc[2][i] = Integer.parseInt(loc.substring(loc.indexOf(dash) + 1, loc.indexOf(at)));
        }
        //System.out.println("chrloc " + chrloc[0].length);

        BufferedReader br1 = new BufferedReader(new FileReader(ddd_aliases));
        List<String> exome_id = new ArrayList<String>();
        List<String> acgh_id = new ArrayList<String>();

        while ((s = br1.readLine()) != null) { // DDD aliases
            //m = p.matcher(s);
            String[] ss = s.split("\t");
            String[] aliases = ss[1].split("\\;\\s");

            for (String al : aliases) {
                //System.out.println(al);
                if (sample_ids.contains(al.trim())) {
                    exome_id.add(ss[0].trim());
                    acgh_id.add(al);
                }
            }
        }
        br1.close();

        //System.out.println("acgh_id size: " + acgh_id.size());

        BufferedReader br2 = new BufferedReader(new FileReader(chr_list2));

        int se = 0;
        int overlaps = 0;
        int reported = 0;
        int reportable = 0;
        String acghs = "", acghs_ex = "";
        String re1 = "", re2 = "";
        String overlap_cnt = "";
        line = 0; s = "";
        String chrstr = "";
        
        while ((s = br2.readLine()) != null) { // exome list

            chrstr = "";
            if (line != 0) {

                se = 0;
                overlaps = 0;
                reportable = 0;
                reported = 0;
                overlap_cnt = "";

                String[] ss = s.split("\t");
                chr = ss[0];
                start = ss[1];
                end = ss[2];


                if (chr.equalsIgnoreCase("X")) {
                    ch = 23;
                } else if (chr.equalsIgnoreCase("Y")) {
                    ch = 24;
                } else if (chr.equalsIgnoreCase("MT")) {
                    ch = 25;
                } else {
                    ch = Integer.parseInt(chr);
                }
                st = Integer.parseInt(start);
                en = Integer.parseInt(end);

                if (exome_id.contains(ss[sidcol2])) {
                    int eid_index = exome_id.indexOf(ss[sidcol2]);
                    sid = acgh_id.get(eid_index);
                    overlap_cnt = getFrequency(chrloc, ch, st, en, sample_ids, sid, ro_thres);
                } else {
                    overlap_cnt = "";
                }
                //System.out.println("overlap_cnt: "+overlap_cnt);
                if (overlap_cnt.equals("@")) {
                    se = 1;
                } else if (!overlap_cnt.equals("")) {
                    String[] overlapping_indexes = overlap_cnt.split("\\;");
                    se = 1;
                    overlaps = 1;
                    for (String kk : overlapping_indexes) {
                        acghs = chr_start.get(Integer.parseInt(kk));
                        acghs_ex = chr_start_extras.get(Integer.parseInt(kk));
                        
                        re1 = acghs.substring(acghs.indexOf(at) + 1, acghs.lastIndexOf(";"));
                        re2 = acghs.substring(acghs.lastIndexOf(";") + 1);
                        if (re1.equals("TRUE")) {
                            reported = 1;
                        }
                        if (re2.equals("TRUE")) {
                            reportable = 1;
                        }
                        String[] ml_chr = acghs_ex.split("\t");
                        //chrstr += ml_chr[2] + colon + ml_chr[3] + dash + ml_chr[4] + at + ss[9] + ";";
                        chrstr += ml_chr[2] + tab + ml_chr[3] + tab + ml_chr[4] + tab + ml_chr[9];

                    }
                }
                System.out.println(s + tab + se + tab + overlaps + tab + reported + tab + reportable + tab + chrstr);
            }
            ++line;
        }
        br2.close();

    }
    
    public static String getFrequency(int[][] chrloc, int ch, int start, int end, List<String> sample_ids, String current_sample_id, int ro_thres) {

        int ocase = 0;
        double[] opp = {0.0, 0.0, 0.0};

        String overlap_str = "";
        boolean sample_exists = false;

        for (int i = 0; i < chrloc[0].length; i++) {

            if (current_sample_id.equals(sample_ids.get(i)) && chrloc[0][i] == ch) {
                sample_exists = true;
                if (start >= chrloc[1][i] && start <= chrloc[2][i]) {

                    if (chrloc[2][i] >= start && chrloc[2][i] <= end) {
                        ocase = 1;
                    } else {
                        ocase = 2;
                    }
                    opp = getOverlapLength(start, end, chrloc[1][i], chrloc[2][i], ocase);
                    if (opp[1] > ro_thres && opp[2] > ro_thres) {
                        overlap_str += i + ";";
                    }

                } else if (chrloc[1][i] >= start && chrloc[1][i] <= end) {
                    if (chrloc[2][i] >= start && chrloc[2][i] <= end) {
                        ocase = 3;
                    } else {
                        ocase = 4;
                    }
                    opp = getOverlapLength(start, end, chrloc[1][i], chrloc[2][i], ocase);
                    if (opp[1] > ro_thres && opp[2] > ro_thres) {
                        overlap_str += i + ";";
                    }
                }
            }
        }
        if (overlap_str.equals("") && sample_exists) {
            overlap_str = "@";
        }
        return overlap_str;
    }

    public static double[] getOverlapLength(int start, int end, int chrloc_start, int chrloc_end, int ocase) {

        double[] opp = {0.0, 0.0, 0.0};
        double exl = (double) (end - start + 1);
        double exl2 = (double) (chrloc_end - chrloc_start + 1);

        switch (ocase) {
            case 1:
                opp[0] = (double) (chrloc_end - start + 1);
                opp[1] = opp[0] * 100.0 / exl;
                opp[2] = opp[0] * 100.0 / exl2;
                break;
            case 2:
                opp[0] = exl;
                opp[1] = 100.0;
                opp[2] = exl * 100.0 / exl2;
                break;
            case 3:
                opp[0] = chrloc_end - chrloc_start + 1;
                opp[1] = opp[0] * 100.0 / exl;
                opp[2] = opp[0] * 100.0 / exl2;
                break;
            case 4:
                opp[0] = end - chrloc_start + 1;
                opp[1] = opp[0] * 100.0 / exl;
                opp[2] = opp[0] * 100.0 / exl2;
                break;
        }
        return opp;
    }

    public static void main(String[] args) throws Exception {
        new CompareLists().estimateFreq(args);
    }
}
