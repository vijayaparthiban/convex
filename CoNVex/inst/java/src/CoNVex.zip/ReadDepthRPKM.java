
/**
 * @author Parthiban Vijayarangakannan - pv1@sanger.ac.uk Genome Mutation and
 * Genetic Disease (Team 29) The Sanger Institute
 */
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.sf.samtools.*;
import net.sf.samtools.BAMIndexMetaData;
import net.sf.samtools.SAMFileReader.ValidationStringency;
import net.sf.samtools.util.CloseableIterator;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class ReadDepthRPKM {

    @Option(name = "-bam_file", usage = "bam or cram file location of the sample")
    private String bam_file = "";
    @Option(name = "-regions_file", usage = "File with Chr regions: chr (1,2,..X,Y), start, end")
    private String gff_file = "";
    @Option(name = "-rd_file", usage = "Output file: No. of reads and mean depths of the given probe regions")
    private String rd_file = "";
    @Option(name = "-bamindex_file", usage = "(optional) Index file of the bam file, if exists in different folder or in a different file name")
    private String bamindex_file = "";
    @Option(name = "-chr_prefix", usage = " (optional) Chr prefix in bam files [if you observe 'Chr1', use 'Chr' (without quotes). Default: no prefix (expects 1,2,..X,Y)]")
    private String chr_prefix = "";
    private File bamFile = null;
    private File bamIndexFile = null;
    static final String dash = "-", colon = ":", newline = "\n", tab = "\t", nstr = "";
    private SAMFileReader inputSam = null;
    private boolean containsbamRecord = false;//false : the alignment of the returned SAMRecords need only overlap the interval of interest.

    public void open(File bamFile) {
        close();
        this.bamFile = bamFile;
        this.inputSam = new SAMFileReader(this.bamFile);
        this.inputSam.setValidationStringency(ValidationStringency.SILENT);
    }

    public void open(File bamFile, File bamIndexFile) {
        close();
        this.bamFile = bamFile;
        this.bamIndexFile = bamIndexFile;
        this.inputSam = new SAMFileReader(this.bamFile, this.bamIndexFile);
        this.inputSam.setValidationStringency(ValidationStringency.SILENT);
    }

    public void close() {
        if (inputSam != null) {
            inputSam.close();
        }
        this.inputSam = null;
        this.bamFile = null;
    }

    private int getTotalMappedReadCount(SAMFileReader sam) {
        int count = 0;

        AbstractBAMFileIndex index = (AbstractBAMFileIndex) sam.getIndex();
        int nRefs = index.getNumberOfReferences();
        for (int i = 0; i < nRefs; i++) {
            BAMIndexMetaData meta = index.getMetaData(i);
            count += meta.getAlignedRecordCount();
        }
        return count;
    }

    private double[] getReadsDepths(String chr, int start, int end) throws IOException {
        //chr = "Chr1";
        double[] reads_depths = new double[3];
        double mrd = 0;
        int reg_len = end - start + 1;
        int[] probeBaseCoverage = new int[reg_len];
        int nCount = 0;
        int read_start = 0, read_end = 0;
        int[] pbc_start_end = new int[2];
        int mapped_reads = getTotalMappedReadCount(this.inputSam);

                        System.out.println("mapped reads = "+mapped_reads);

        CloseableIterator<SAMRecord> iter = null;

        try {
            iter = this.inputSam.query(chr, start, end, this.containsbamRecord);

            while (iter.hasNext()) { // For each read

                SAMRecord rec = iter.next();

                if (!rec.getDuplicateReadFlag()) { // Removal of PCR duplicates

                    read_start = rec.getAlignmentStart();
                    read_end = rec.getAlignmentEnd();
                    if (read_end != 0) {
                        ++nCount; // No of reads

                        pbc_start_end = getReadRange(start, end, read_start, read_end);

                        for (int i = pbc_start_end[0]; i <= pbc_start_end[1]; i++) {
                            ++probeBaseCoverage[i];
                        }
                    }
                }
            }
        } catch (Exception e) {
            throw new IOException(e);
        } finally {
            if (iter != null) {
                iter.close();
            }
        }

        for (int i = 0; i < probeBaseCoverage.length; i++) {
            mrd += probeBaseCoverage[i];
        }
        mrd /= (double) reg_len;
        mrd = Math.round(mrd * 100.0) / 100.0;
        reads_depths[0] = nCount;
        reads_depths[1] = mrd;
        reads_depths[2] = (1e9 * nCount) / (mapped_reads * reg_len);
        return reads_depths;
    }

    private int[] getReadRange(int chr_start, int chr_end, int read_start, int read_end) {

        int[] start_end = new int[2];
        int ocase = 0; // Overlap case: Probe/Exon vs Aligned read

        if (read_start >= chr_start && read_start <= chr_end) {
            if (read_end >= chr_start && read_end <= chr_end) {
                ocase = 1;
                start_end[0] = read_start - chr_start;
                start_end[1] = read_end - chr_start;
            } else {
                ocase = 2;
                start_end[0] = read_start - chr_start;
                start_end[1] = chr_end - chr_start;
            }

        } else if (chr_start >= read_start && chr_start <= read_end) {
            if (read_end >= chr_start && read_end <= chr_end) {
                ocase = 3;
                start_end[0] = 0;
                start_end[1] = read_end - chr_start;

            } else {
                ocase = 4;
                start_end[0] = 0;
                start_end[1] = chr_end - chr_start;
            }
        }
        return start_end;
    }

    public void getExomeCoverage(String[] args) throws Exception {

        CmdLineParser parser = new CmdLineParser(this);
        try {
            parser.parseArgument(args);
        } catch (CmdLineException cle) {
            System.err.println(cle.getMessage());
            parser.printUsage(System.err);
        }

        if (bam_file.equals("") || gff_file.equals("") || rd_file.equals("")) {
            System.err.println("Required options are missing!");
            System.err.println("Usage: java ReadDepthV2 -bam_file /path/to/file.bam -bamindex_file /path/to/bamindexfile.bai -regions_file /path/to/file.txt -rd_file /path/to/output/file/region_reads_depth.dat");
            System.err.println("Type -help or -<anyjunk> to display the options :)");
            System.exit(-1);
        }

        BufferedReader br = new BufferedReader(new FileReader(gff_file));
        BufferedWriter bw = new BufferedWriter(new FileWriter(rd_file));
        Pattern p = Pattern.compile("^([\\dXYMT]+)\\t(\\d+)\\t(\\d+).*"); // chr, start, end
        //Pattern p = Pattern.compile("^([\\dXYMT]+)\\t.+\\t(\\d+)\\t(\\d+)\\t.+\\t.+\\t.+"); // GFF file pattern
        //Pattern pchr = Pattern.compile("^chr([\\dXYMT]+)\\t.+\\t(\\d+)\\t(\\d+)\\t.+\\t.+\\t.+"); // GFF file pattern

        Matcher m = null;
        String chr = "";
        int start = 0, end = 0;
        String s = "";
        int read_check = 0;

        ReadDepthRPKM app = new ReadDepthRPKM();

        if (!bamindex_file.equals("")) {
            System.out.println("Running with index file:");
            System.out.println(bamindex_file);
            app.open(new File(bam_file), new File(bamindex_file));
        } else {
            app.open(new File(bam_file));
        }

        while ((s = br.readLine()) != null) { // Read-in the GFF file

            m = p.matcher(s);

            if (m.find()) {

                chr = m.group(1);
                start = Integer.parseInt(m.group(2));
                end = Integer.parseInt(m.group(3));

                double[] reads_depths = new double[3];
                reads_depths[0] = 0; // No. of reads
                reads_depths[1] = 0; // Mean read depth
                reads_depths[2] = 0; // RPKM / FPKM

                reads_depths = app.getReadsDepths(chr_prefix + chr, start, end);
                //System.out.println(chr + tab + start + tab + end + tab + " >> Reads = " + (int)reads_depths[0] + " / Depth = " + reads_depths[1]);
                bw.write(chr + tab + start + tab + end + tab + (int) reads_depths[0] + tab + reads_depths[1] + tab + reads_depths[2] + newline);
                read_check += reads_depths[0];
            }
        }
        if (read_check == 0) {
            System.err.println("No reads were found. Possible reason(s):");
            System.err.println("# Check the bam file and the bam index file");
            System.err.println("# Check '-chr_prefix' option - chr format in bam file may be 'Chr1','chr1', etc.");
            System.err.println("# Generated output read depth files may contain 0 reads. You may delete/overwrite them");
            System.exit(1);
        }
        br.close(); // Close the opened chr regions file
        bw.close(); // Close the output file
        app.close(); // Close the bam file for further queries
    }

    public static void main(String[] args) throws Exception {
        new ReadDepthRPKM().getExomeCoverage(args);
    }
}