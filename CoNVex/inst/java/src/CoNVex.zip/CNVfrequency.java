
/**
 * @author Parthiban Vijayarangakannan - pv1@sanger.ac.uk Genome Mutation and
 * Genetic Disease (Team 29) The Sanger Institute
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class CNVfrequency {

    @Option(name = "-chr_list1", usage = "List 1 with Chr regions (Chr, Start and End) in the first 3 columns ")
    private String chr_list1 = "";
    @Option(name = "-chr_list2", usage = "List 2 with Chr regions - % overlap of this list is returned as output")
    private String chr_list2 = "";
    @Option(name = "-sampleID_col1", usage = "(optional) The column number (count starts from 1) of the Sample ID")
    private String sampleID_col1 = "";
    @Option(name = "-sampleID_col2", usage = "(optional) The column number (count starts from 1) of the Sample ID")
    private String sampleID_col2 = "";
    @Option(name = "-ro_threshold", usage = "(optional) Reciprocal overlap threshold in percentage")
    private String ro_threshold = "0";
    public static final String dash = "-", colon = ":", newline = "\n", tab = "\t", nstr = "";

    public void estimateFreq(String[] args) throws Exception {

        CmdLineParser parser = new CmdLineParser(this);
        try {
            parser.parseArgument(args);
        } catch (CmdLineException cle) {
            System.err.println(cle.getMessage());
            parser.printUsage(System.err);
        }

        if (chr_list1.equals("")) {
            System.err.println("Two lists of Chr regions are required!");
            System.err.println("Usage: java ChrOverlap -chr_list1 /path/to/chr_file1.txt -chr_list2 /path/to/chr_file2.txt");
            System.err.println("Type -help or -<anyjunk> to display the options :)");
            System.exit(-1);
        }
        int sidcol1 = 6; //
        if (!sampleID_col1.equals("")) {
            sidcol1 = Integer.parseInt(sampleID_col1) - 1; //
        }
        int sidcol2 = 6; //
        if (!sampleID_col2.equals("")) {
            sidcol2 = Integer.parseInt(sampleID_col2) - 1; //
        }
        int ro_thres = Integer.parseInt(ro_threshold);
        //System.err.println("Comparing Chr lists:");
        //System.err.println(chr_list1);
        //System.err.println(chr_list2);

        Pattern p = Pattern.compile("^([\\dXYMT]+)\\t(\\d+)\\t(\\d+).*"); // For consensus report
        Matcher m = null;

        BufferedReader br = new BufferedReader(new FileReader(chr_list1));
        String s = "";
        String chr = "", start = "", end = "";
        int ch = 0, st = 0, en = 0;

        List<String> chr_start = new ArrayList<String>();
        List<String> sample_ids = new ArrayList<String>();

        while ((s = br.readLine()) != null) {
            //m = p.matcher(s);
            String[] ss = s.split("\t");
            chr = ss[0];
            start = ss[1];
            end = ss[2];
            chr_start.add(chr + colon + start + dash + end);
            sample_ids.add(ss[sidcol1]);
        }
        br.close();

        int[][] chrloc = new int[3][chr_start.size()];
        int[] sidtrack = new int[chr_start.size()];
        String sid = "";
        int sidcount = 0;

        for (int i = 0; i < chr_start.size(); i++) {

            String loc = chr_start.get(i);
            String stmp = sample_ids.get(i);

            if (!sid.equals(stmp)) {
                sid = stmp;
                ++sidcount;
            }
            sidtrack[i] = sidcount;
            chr = loc.substring(0, loc.indexOf(colon)).trim();

            if (chr.equalsIgnoreCase("X")) {
                ch = 23;
            } else if (chr.equalsIgnoreCase("Y")) {
                ch = 24;
            } else if (chr.equalsIgnoreCase("MT")) {
                ch = 25;
            } else {
                ch = Integer.parseInt(chr);
            }
            chrloc[0][i] = ch;
            chrloc[1][i] = Integer.parseInt(loc.substring(loc.indexOf(colon) + 1, loc.lastIndexOf(dash)).trim());
            chrloc[2][i] = Integer.parseInt(loc.substring(loc.indexOf(dash) + 1).trim());
        }

        int[] overlap_counts = new int[chrloc[0].length];
        sidcount = 0;

        if (!chr_list2.equals("")) {

            BufferedReader br1 = new BufferedReader(new FileReader(chr_list2));
            chr_start = new ArrayList<String>();
            sample_ids = new ArrayList<String>();

            while ((s = br1.readLine()) != null) {

                String[] ss = s.split("\t");
                chr = ss[0];
                start = ss[1];
                end = ss[2];
                chr_start.add(chr + colon + start + dash + end);
                sample_ids.add(ss[sidcol2]);
            }

            int[][] chrloc2 = new int[3][chr_start.size()];
            int[] sidtrack2 = new int[chr_start.size()];

            for (int i = 0; i < chr_start.size(); i++) {

                String loc = chr_start.get(i);
                String stmp = sample_ids.get(i);

                if (!sid.equals(stmp)) {
                    sid = stmp;
                    ++sidcount;
                }
                sidtrack2[i] = sidcount;
                chr = loc.substring(0, loc.indexOf(colon)).trim();

                if (chr.equalsIgnoreCase("X")) {
                    ch = 23;
                } else if (chr.equalsIgnoreCase("Y")) {
                    ch = 24;
                } else if (chr.equalsIgnoreCase("MT")) {
                    ch = 25;
                } else {
                    ch = Integer.parseInt(chr);
                }
                chrloc2[0][i] = ch;
                chrloc2[1][i] = Integer.parseInt(loc.substring(loc.indexOf(colon) + 1, loc.lastIndexOf(dash)).trim());
                chrloc2[2][i] = Integer.parseInt(loc.substring(loc.indexOf(dash) + 1).trim());
            }
            for (int j = 0; j < chrloc[0].length; j++) {
                ch = chrloc[0][j];
                st = chrloc[1][j];
                en = chrloc[2][j];
                int overlap_cnt = getFrequency(chrloc2, ch, st, en, sidtrack2, ro_thres);
                overlap_counts[j] = overlap_cnt;
            }

        } else {
            for (int j = 0; j < chrloc[0].length; j++) {
                ch = chrloc[0][j];
                st = chrloc[1][j];
                en = chrloc[2][j];
                int overlap_cnt = getFrequency(chrloc, ch, st, en, sidtrack, ro_thres);
                overlap_counts[j] = overlap_cnt;
            }
        }
        for (int ii = 0; ii < overlap_counts.length; ii++) {
            System.out.println(overlap_counts[ii]);
        }
    }

    public static int getFrequency(int[][] chrloc, int ch, int start, int end, int[] sidtrack, int ro_thres) {

        int ocase = 0;
        double[] opp = {0.0, 0.0, 0.0};

        int overlap_cnt = 0;
        int ol_test = 0;
        int sidtmp = 0;

        for (int i = 0; i < chrloc[0].length; i++) {

            if (chrloc[0][i] == ch) {

                if (start >= chrloc[1][i] && start <= chrloc[2][i] && sidtmp != sidtrack[i]) {

                    if (chrloc[2][i] >= start && chrloc[2][i] <= end) {
                        ocase = 1;
                    } else {
                        //System.out.println(chrloc[1][i] + "; " + chrloc[2][i] + "; " + start + "; " + end + "; " + opp[1]+"; "+opp[2]);
                        ocase = 2;
                    }
                    opp = getOverlapLength(start, end, chrloc[1][i], chrloc[2][i], ocase);
                    if (opp[1] > ro_thres && opp[2] > ro_thres) {
                        ++overlap_cnt;
                        sidtmp = sidtrack[i];
                        //System.out.println("oc1/2: opp[1]: " + opp[1] + ", opp[2]: " + opp[2]);
                    }

                } else if (chrloc[1][i] >= start && chrloc[1][i] <= end && sidtmp != sidtrack[i]) {
                    if (chrloc[2][i] >= start && chrloc[2][i] <= end) {
                        ocase = 3;
                    } else {
                        ocase = 4;
                    }
                    opp = getOverlapLength(start, end, chrloc[1][i], chrloc[2][i], ocase);
                    if (opp[1] > ro_thres && opp[2] > ro_thres) {
                        ++overlap_cnt;
                        sidtmp = sidtrack[i];
                        // System.out.println("oc1/2: opp[1]: " + opp[1] + ", opp[2]: " + opp[2]);
                    }
                }
            }
        }

        return overlap_cnt;
    }

    public static double[] getOverlapLength(int start, int end, int chrloc_start, int chrloc_end, int ocase) {

        double[] opp = {0.0, 0.0, 0.0};
        double exl = (double) (end - start + 1);
        double exl2 = (double) (chrloc_end - chrloc_start + 1);

        switch (ocase) {
            case 1:
                opp[0] = (double) (chrloc_end - start + 1);
                opp[1] = opp[0] * 100.0 / exl;
                opp[2] = opp[0] * 100.0 / exl2;
                break;
            case 2:
                opp[0] = exl;
                opp[1] = 100.0;
                opp[2] = exl * 100.0 / exl2;
                break;
            case 3:
                opp[0] = chrloc_end - chrloc_start + 1;
                opp[1] = opp[0] * 100.0 / exl;
                opp[2] = opp[0] * 100.0 / exl2;
                break;
            case 4:
                opp[0] = end - chrloc_start + 1;
                opp[1] = opp[0] * 100.0 / exl;
                opp[2] = opp[0] * 100.0 / exl2;
                break;
        }
        return opp;
    }

    public static void main(String[] args) throws Exception {
        new CNVfrequency().estimateFreq(args);
    }
}
