
import java.io.*;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

/*
 * To change this template, choose Tools | Templates and open the template in
 * the editor.
 */
/**
 * @author Parthiban Vijayarangakannan - pv1@sanger.ac.uk Genome Dynamics and
 * Evolution Group (Team 29) The Sanger Institute
 */
public class CNVindexer {

    @Option(name = "-regions_file", usage = "List of active PSICQUIC clients (optional)")
    private String regions_file = "";
    @Option(name = "-cnv_list", usage = "CNV list - CoNVex output!")
    private String cnv_list = "";
    @Option(name = "-num_probes", usage = "number of probe regions!")
    private String num_probes = "";
    public static final String dash = "-", colon = ":", newline = "\n", tab = "\t", nstr = "";

    public void generateIndex(String[] args) throws Exception {

        // Get the interaction lists
        CmdLineParser parser = new CmdLineParser(this);
        try {
            parser.parseArgument(args);
        } catch (CmdLineException cle) {
            System.err.println(cle.getMessage());
            parser.printUsage(System.err);
        }

        if (cnv_list.equals("") || num_probes.equals("") || regions_file.equals("")) {

            System.err.println("Usage: java CNVindexer -regions_file /path/to/chr_regions_file.txt -cnv_list /path/to/cnv_list.txt");
            System.err.println("Type -help or -<anyjunk> to display the options :)");
            System.exit(-1);
        }
        String output_file = cnv_list.substring(0, cnv_list.lastIndexOf(".")) + ".IND.txt";
        //String output_file_cs = cnv_gene_list.substring(0, cnv_gene_list.lastIndexOf(".")) + "_ppi_cs.txt";
        //String output_file_within = cnv_gene_list.substring(0, cnv_gene_list.lastIndexOf(".")) + "_ppi_within.txt";

        String s = "";
        String chr = "", start = "", end = "";
        int ch = 0, st = 0, en = 0, i = 0;

        int count1 = 0;
        //String chr = "", start = "", end = "";

        //Pattern p = Pattern.compile("^([\\dXYMT]+)\\t(\\d+)\\t(\\d+).*"); // chr, start, end
        //Pattern p1 = Pattern.compile("^[\\dXYMT]+\\t\\d+\\t\\d+\\t.+\\t.+\\t(.+)\\t.*"); // chr, start, end
        Pattern p = Pattern.compile("^([\\dXYMT]+)\\t(\\d+)\\t(\\d+).*"); // For consensus report
        //Pattern p1 = Pattern.compile("^\\d+\\t([\\dXYMT]+)\\t(\\d+)\\t(\\d+)\\t[\\d\\t]+{14}"); // Pileup summary list
        //Pattern p2 = Pattern.compile("^.+\\t(\\d+\\t\\d+\\t\\d+\\t\\d+\\t\\d+\\t\\d+\\t[\\d\\.]+\\t[\\d\\.]+\\t[\\d\\.]+)");
        Matcher m = null, m1 = null, m2 = null;


        HashMap<String, String> probe_regions = new HashMap<String, String>();
        BufferedReader br = new BufferedReader(new FileReader(regions_file));
        /*
         * while ((s = br.readLine()) != null) { ++count1;
         * probe_regions.put(nstr + count1, s); } br.close(); s = "";
         *
         */

        int[][] chrloc = new int[3][Integer.parseInt(num_probes)];

        //for (String loc : probe_regions.keySet()) {
        while ((s = br.readLine()) != null) {

            m = p.matcher(s);
            if (m.find()) {
                chr = m.group(1);
                start = m.group(2);
                end = m.group(3);

                //System.out.println("chr "+s);
                if (chr.equalsIgnoreCase("X")) {
                    ch = 23;
                } else if (chr.equalsIgnoreCase("Y")) {
                    ch = 24;
                } else if (chr.equalsIgnoreCase("MT")) {
                    ch = 25;
                } else {
                    ch = Integer.parseInt(chr);
                }
                chrloc[0][i] = ch;
                chrloc[1][i] = Integer.parseInt(start);
                chrloc[2][i] = Integer.parseInt(end);
                ++i;
            }
        }

        BufferedReader br1 = new BufferedReader(new FileReader(cnv_list));
        s = "";
        ch = 0;
        i = 0;
        int[] probe_indexes = {0, 0};

        while ((s = br1.readLine()) != null) {

            probe_indexes[0] = 0;
            probe_indexes[1] = 0;

            m1 = p.matcher(s);

            if (m1.find()) {
                chr = m1.group(1);

                if (chr.equalsIgnoreCase("X")) {
                    ch = 23;
                } else if (chr.equalsIgnoreCase("Y")) {
                    ch = 24;
                } else if (chr.equalsIgnoreCase("MT")) {
                    ch = 25;
                } else {
                    ch = Integer.parseInt(chr);
                }
                st = Integer.parseInt(m1.group(2));
                en = Integer.parseInt(m1.group(3));

                probe_indexes = getIndexes(chrloc, ch, st, en);
                System.out.println(s + tab + probe_indexes[0] + tab + probe_indexes[1] + newline);
            }

        }
    }

    public static int[] getIndexes(int[][] chrloc, int ch, int start, int end) {

        int ocase = 0;
        int[] indexes = {0, 0};

        for (int i = 0; i < chrloc[0].length; i++) {
            ocase = 0;
            if (chrloc[0][i] == ch) {
                if (start >= chrloc[1][i] && start <= chrloc[2][i]) {
                    ocase = 2;
                } else if (chrloc[1][i] >= start && chrloc[1][i] <= end) {
                    ocase = 4;
                }
            }
            if (ocase > 0) {
                if (indexes[0] == 0) {
                    indexes[0] = i + 1;
                    indexes[1] = i + 1;
                }
            } else {
                if (indexes[0] > 0) {
                    indexes[1] = i;
                    break;
                }
            }
        }
        return indexes;
    }

    public static void main(String[] args) throws Exception {
        new CNVindexer().generateIndex(args);
    }
}
